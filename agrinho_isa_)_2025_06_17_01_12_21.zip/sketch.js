let tela = 1;
let imgCenario3;
let quizResposta = null;

// Variáveis do jogo final
let jogador;
let itens = [];
let pontos = 0;

function preload() {
  imgCenario3 = loadImage('agrinho 3.png'); // sua imagem
}

function setup() {
  createCanvas(700, 600);
  textFont('Arial');
  jogador = createVector(width / 2, height - 50);
  for (let i = 0; i < 5; i++) {
    itens.push(novoItem());
  }
}

function draw() {
  if (tela === 1) {
    background("lightpink");
    fill("black");
    textSize(32);
    text("Bem-vindo ao Agrinho 2025!💗", 150, 300);
    textSize(20);
    text("(Pressione ENTER para continuar)", 200, 350);

  } else if (tela === 2) {
    background("lightblue");
    fill("black");
    textSize(30);
    text("Hoje o assunto abordado será:", 150, 200);
    textSize(20);
    text("𝐒𝐮𝐬𝐭𝐞𝐧𝐭𝐚𝐛𝐢𝐥𝐢𝐝𝐚𝐝𝐞 𝐞𝐧𝐭𝐫𝐞 𝐂𝐚𝐦𝐩𝐨 𝐞 𝐂𝐢𝐝𝐚𝐝𝐞", 150, 250);
    textSize(200);
    text("🏘️🏙️", 100, 490);

  } else if (tela === 3) {
    image(imgCenario3, 0, 0, width, height);
    fill("black");
    textSize(22);
    text("𝘈𝘱𝘦𝘴𝘢𝘳 𝘥𝘦 𝘴𝘶𝘢𝘴 𝘥𝘪𝘧𝘦𝘳𝘦𝘯𝘤̧𝘢𝘴, 𝘰 𝘤𝘢𝘮𝘱𝘰 𝘦", 34, 57);
    text("𝘢 𝘤𝘪𝘥𝘢𝘥𝘦 𝘦𝘴𝘵𝘢̃𝘰 𝘴𝘦𝘮𝘱𝘳𝘦 𝘤𝘰𝘯𝘦𝘤𝘵𝘢𝘥𝘰𝘴!", 34, 90);
    text("𝘈 𝘤𝘪𝘥𝘢𝘥𝘦 𝘥𝘦𝘱𝘦𝘯𝘥𝘦 𝘥𝘰 𝘤𝘢𝘮𝘱𝘰 𝘱𝘢𝘳𝘢 𝘴𝘦", 300, 200);
    text("𝘢𝘭𝘪𝘮𝘦𝘯𝘵𝘢𝘳, 𝘦 𝘰 𝘤𝘢𝘮𝘱𝘰 𝘥𝘦𝘱𝘦𝘯𝘥𝘦 𝘥𝘢 𝘤𝘪𝘥𝘢𝘥𝘦", 290, 234);
    text("𝘱𝘢𝘳𝘢 𝘷𝘦𝘯𝘥𝘦𝘳 𝘰 𝘲𝘶𝘦 𝘱𝘳𝘰𝘥𝘶𝘻 𝘦 𝘵𝘦𝘳 𝘢𝘤𝘦𝘴𝘴𝘰", 290, 266);
    text("𝘢 𝘴𝘦𝘳𝘷𝘪𝘤̧𝘰𝘴, 𝘵𝘦𝘤𝘯𝘰𝘭𝘰𝘨𝘪𝘢 𝘦 𝘱𝘳𝘰𝘥𝘶𝘵𝘰𝘴.", 290, 297);
    text("(𝘤𝘭𝘪𝘲𝘶𝘦 𝘦𝘯𝘵𝘦𝘳 𝘱𝘢𝘳𝘢 𝘤𝘰𝘯𝘵𝘪𝘯𝘶𝘢𝘳)", 400, 420);

  } else if (tela === 4) {
    background("lightgreen");
    fill("black");
    textSize(22);
    text("🌿➡︎ Exemplos de Sustentabilidade:", 180, 80);
    textSize(20);
    text("- Agricultura orgânica e sem agrotóxicos", 100, 179);
    text("- Hortas urbanas em escolas e bairros", 100, 210);
    text("- Reciclagem e compostagem de resíduos", 100, 240);
    text("- Uso consciente da água e energia", 100, 270);
    text("𝘤𝘭𝘪𝘲𝘶𝘦 𝘦𝘯𝘵𝘦𝘳 𝘱𝘢𝘳𝘢 𝘳𝘦𝘴𝘱𝘰𝘯𝘥𝘦𝘳 𝘰 𝘲𝘶𝘪𝘻 𝘚𝘶𝘴𝘵𝘦𝘯𝘵𝘢𝘣𝘪𝘭𝘪𝘥𝘢𝘥𝘦 𝘯𝘰 𝘊𝘢𝘮𝘱𝘰", 100, 400);

  } else if (tela === 5) {
    background("lightyellow");
    fill("black");
    textSize(22);
    text("𝐐𝐮𝐚𝐥 𝐞́ 𝐮𝐦𝐚 𝐚𝐜̧𝐚̃𝐨 𝐬𝐮𝐬𝐭𝐞𝐧𝐭𝐚́𝐯𝐞𝐥 𝐧𝐨 𝐜𝐚𝐦𝐩𝐨?", 150, 150);
    textSize(20);
    text("A) Desmatar para plantar mais rápido", 150, 200);
    text("B) Usar energia solar e irrigação consciente", 150, 230);
    text("C) Jogar lixo no rio", 150, 260);
    text("➡︎ (𝐏𝐫𝐞𝐬𝐬𝐢𝐨𝐧𝐞 𝐀, 𝐁 𝐨𝐮 𝐂)", 200, 320);

    if (quizResposta !== null) {
      fill(quizResposta === 'B' ? '#C124B9' : 'red');
      textSize(20);
      if (quizResposta === 'B') {
        text("✅ Correto! Usar energia solar e irrigação consciente é sustentável.", 50, 380);
      } else {
        text("❌ Errado! Tente novamente ou revise o conteúdo.", 100, 380);
      }
    }

  } else if (tela === 6) {
    background("lavender");
    fill("black");
    textSize(22);
    text("🌱 𝘖 𝘤𝘢𝘮𝘱𝘰 𝘦 𝘢 𝘤𝘪𝘥𝘢𝘥𝘦 𝘱𝘳𝘦𝘤𝘪𝘴𝘢𝘮 𝘤𝘢𝘮𝘪𝘯𝘩𝘢𝘳 𝘫𝘶𝘯𝘵𝘰𝘴.", 100, 200);
    text("𝘈 𝘴𝘶𝘴𝘵𝘦𝘯𝘵𝘢𝘣𝘪𝘭𝘪𝘥𝘢𝘥𝘦 é 𝘰 𝘤𝘢𝘮𝘪𝘯𝘩𝘰 𝘱𝘢𝘳𝘢 𝘶𝘮 𝘧𝘶𝘵𝘶𝘳𝘰 𝘮𝘦𝘭𝘩𝘰𝘳! 🌎", 70, 240);
    textSize(20);
    text("(𝐏𝐫𝐞𝐬𝐬𝐢𝐨𝐧𝐞 𝐞𝐧𝐭𝐞𝐫 𝐩𝐚𝐫𝐚 𝐞𝐧𝐜𝐞𝐫𝐫𝐚𝐫𝐦𝐨𝐬 𝐜𝐨𝐦 𝐮𝐦 𝐣𝐨𝐠𝐨 𝐬𝐨𝐛𝐫𝐞 𝐞𝐬𝐭𝐞 𝐚𝐬𝐬𝐮𝐧𝐭𝐨)", 30, 350);

  } else if (tela === 7) {
    background("#DBB9DB");
    fill("black");
    textSize(22);
    text("🎮 𝐂𝐨𝐥𝐞𝐭𝐚 𝐒𝐮𝐬𝐭𝐞𝐧𝐭𝐚́𝐯𝐞𝐥: 𝐏𝐞𝐠𝐮𝐞 𝐨𝐬 𝐫𝐞𝐜𝐢𝐜𝐥𝐚́𝐯𝐞𝐢𝐬 ♻️ 𝐞 𝐞𝐯𝐢𝐭𝐞 𝐨𝐬 ❌!", 50, 30);
    textSize(18);
    text(`Pontuação: ${pontos}`, 550, 60);

    // Jogador
    fill("#9DE5EE");
    rect(jogador.x, jogador.y, 40, 40);

    // Itens
    for (let i = itens.length - 1; i >= 0; i--) {
      let item = itens[i];
      textSize(30);
      text(item.tipo, item.pos.x, item.pos.y);
      item.pos.y += item.vel;

      // Colisão
      if (dist(jogador.x + 20, jogador.y + 20, item.pos.x, item.pos.y) < 30) {
        if (item.tipo === '♻️') {
          pontos++;
        } else {
          pontos--;
        }
        itens.splice(i, 1);
        itens.push(novoItem());
      } else if (item.pos.y > height) {
        itens.splice(i, 1);
        itens.push(novoItem());
      }
    }

    // Movimento
    if (keyIsDown(LEFT_ARROW)) jogador.x -= 5;
    if (keyIsDown(RIGHT_ARROW)) jogador.x += 5;
    jogador.x = constrain(jogador.x, 0, width - 40);

    if (pontos >= 10) {
      tela = 8;
    }

  } else if (tela === 8) {
    background("#D49ACF");
    fill("black");
    textSize(28);
    text("🎉 Parabéns! Você ajudou a manter o ambiente limpo!", 20, 250);
    textSize(20);
    text("Pressione ESC para reiniciar.", 220, 320);
  }
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (tela < 8) {
      tela++;
      quizResposta = null;
    }
  } else if (keyCode === ESCAPE) {
    tela = 1;
    quizResposta = null;
    pontos = 0;
    jogador = createVector(width / 2, height - 50);
    itens = [];
    for (let i = 0; i < 5; i++) {
      itens.push(novoItem());
    }
  } else if (tela === 5) {
    let keyUpper = key.toUpperCase();
    if (keyUpper === 'A' || keyUpper === 'B' || keyUpper === 'C') {
      quizResposta = keyUpper;
    }
  }
}

function novoItem() {
  return {
    pos: createVector(random(50, width - 50), 0),
    vel: random(1, 2, 5),
    tipo: random(['♻️', '❌'])
  };
}
